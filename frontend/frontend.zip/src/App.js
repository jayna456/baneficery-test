import Register from "./Register";

function App() {
  return (
    <>
      welcome      
    </>
  );
}

export default App;
