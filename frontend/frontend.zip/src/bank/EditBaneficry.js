import React from 'react'

const EditBaneficry = () => {
  return (
    <div>EditBaneficry</div>
  )
}

export default EditBaneficry